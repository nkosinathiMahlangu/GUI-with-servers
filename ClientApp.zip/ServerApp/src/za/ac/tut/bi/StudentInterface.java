/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bi;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Student
 */
public interface StudentInterface<S>{
    boolean store(S s) throws SQLException;
    boolean delete(Integer num) throws SQLException;
    List<S> get()throws SQLException;
}

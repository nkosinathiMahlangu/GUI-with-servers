/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bi;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.ac.tut.entity.StudentDetails;

/**
 *
 * @author Student
 */
public class StudentThread extends Thread{
    private Socket socket;
    private BufferedReader in;
    private PrintWriter send;
     StudentManager sm;

    public StudentThread() {
    }

    public StudentThread(Socket socket) throws SQLException, IOException  {
        this.socket = socket;
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        send = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
        sm = new StudentManager("jdbc:derby://localhost:1527/StudentDB","app","123");
        start();
    }
    @Override
    public void run(){
        //Vsriables
       String data="",name,surname,get,dis = null,food = null;
       Character gender;
       Integer option,id;
       Date dob;
       StudentDetails ss;
        try {
            //Reading data
            data = in.readLine();
            while(!data.equals("exit")){
              //Array
           String[] token = data.split("#");
           //first value of data
           option = Integer.parseInt(token[0]);
         
               if(option == 1){
                   id = Integer.parseInt(token[1]);
                   name = token[2];
                   surname = token[3];
                   gender = token[4].charAt(0);
                   dob = Date.valueOf(token[5]);
                   dis = token[6];
                   food = token[7];
                   ss = new StudentDetails(id,name,surname,gender,dob,dis,food);
                   sm.store(ss);
                   send.println("Details stored in database");
               }else if(option == 2){
                     id = Integer.parseInt(token[1]);
                     sm.delete(id);
                     send.println("Data deleted");
               }else if(option == 3){
                
                   get = token[1];
                   System.out.println(get);
                   
                   List<StudentDetails> list = new ArrayList();

                   list = sm.get();
                   send.println(list);
                    
               }
            data = in.readLine();
          
           
            } 
            System.out.println("exit");
            
        } catch (IOException ex) {
            Logger.getLogger(StudentThread.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StudentThread.class.getName()).log(Level.SEVERE, null, ex);
     
    }
        
        finally{
           try {
               System.err.println("Closed");
               in.close();
               send.close();
               socket.close();
               
              
           } catch (IOException ex) {
               Logger.getLogger(StudentThread.class.getName()).log(Level.SEVERE, null, ex);
          
     }
        }
    
}
    }
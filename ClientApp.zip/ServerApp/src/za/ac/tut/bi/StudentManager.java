/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bi;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import za.ac.tut.entity.StudentDetails;

/**
 *
 * @author Student
 */
public class StudentManager implements StudentInterface<StudentDetails>{
   private Connection connection;

    public StudentManager(String url,String user, String pass) throws SQLException {
        connection = DriverManager.getConnection(url, user, pass);
    }
   
    @Override
    public synchronized boolean store(StudentDetails s) throws SQLException {
       String sql = "INSERT INTO STUDENTTB(ID,NAME,SURNAME,GENDER,DOB,DISABILITY,FOOD,CREATIONTIME) "+
                     "VALUES(?,?,?,?,?,?,?,?)";
       PreparedStatement ps= connection.prepareStatement(sql);
       ps.setInt(1, s.getId());
       ps.setString(2, s.getName());
       ps.setString(3, s.getSurname());
       ps.setString(4, s.getGender().toString());
       ps.setDate(5, s.getDob());
       ps.setString(6, s.getDisability());
       ps.setString(7, s.getFood());
       ps.setTimestamp(8, Timestamp.from(Instant.now()));
       ps.executeUpdate();
       ps.close();
       return true;
    }

    @Override
    public synchronized boolean delete(Integer num) throws SQLException {
      String sql = "DELETE FROM STUDENTTB "+
                   "WHERE ID=?";
                      
       PreparedStatement ps = connection.prepareStatement(sql);
       ps.setInt(1, num);
       ps.executeUpdate();
       ps.close();
       return true;
       
    }

    @Override
    public synchronized List<StudentDetails> get() throws SQLException {
        String sql = "SELECT ID,NAME,SURNAME,GENDER,DOB,DISABILITY,FOOD FROM STUDENTTB";
        PreparedStatement ps = connection.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        //
        List<StudentDetails> ss = new ArrayList();
        while(rs.next()){
            Integer id = rs.getInt("id");
            String name = rs.getString("name");
            String surname = rs.getString("sURNAME");
            Character gender = rs.getString("Gender").charAt(0);
            Date dob = rs.getDate("DOB");
            String dis = rs.getString("DISABILITY");
            String food = rs.getString("FOOD");
            StudentDetails s = new StudentDetails(id,name,surname,gender,dob,dis,food);
            ss.add(s);
        }
        rs.close();
        return ss;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.entity;

import java.sql.Date;

/**
 *
 * @author Student
 */
public class StudentDetails {
    private Integer id;
    private String name;
    private String surname;
    private Character gender;
    private Date dob;
    private String disability;
    private String food;
    public StudentDetails() {
    }

    public StudentDetails(Integer id, String name, String surname, Character gender, Date dob, String disability, String food) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.gender = gender;
        this.dob = dob;
        this.disability = disability;
        this.food = food;
    }

    public String getDisability() {
        return disability;
    }

    public void setDisability(String disability) {
        this.disability = disability;
    }

    public String getFood() {
        return food;
    }

    public void setFood(String food) {
        this.food = food;
    }



    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Character getGender() {
        return gender;
    }

    public void setGender(Character gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    @Override
    public String toString() {
        return "StudentDetails{" + "id=" + id + ", name=" + name + ", surname=" + surname + ", gender=" + gender + ", dob=" + dob + ", disability=" + disability + ", food=" + food +"#";
    }

   
    
}

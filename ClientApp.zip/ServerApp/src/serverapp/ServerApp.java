/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package serverapp;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import za.ac.tut.bi.StudentThread;

/**
 *
 * @author Student
 */
public class ServerApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        // Variables
        ServerSocket ss;
        Socket socket;
        try {
            
            //Inst vaaria
            ss = new ServerSocket(8585);
              //wati client connect
        System.out.println("Waiting for connection");
        socket = ss.accept(); 
        System.out.println("Client connected");
             //call thread
        StudentThread st = new StudentThread(socket);
        
        } catch (IOException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ServerApp.class.getName()).log(Level.SEVERE, null, ex);
        }
        
      
   
    }
    
}

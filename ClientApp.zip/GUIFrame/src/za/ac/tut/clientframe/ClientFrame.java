/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.clientframe;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author Student
 */
public class ClientFrame extends JFrame{
    //Panels
    private JPanel headingPnl;
    private JPanel idPnl;
    private JPanel namePnl;
    private JPanel surnamePnl;
    private JPanel genderPnl;
    private JPanel dobPnl;
    private JPanel disPnl;
    private JPanel foodPnl;
    private JPanel comboPnl;//griding panel 
    private JPanel headComboPnl;//Border
    private JPanel areaPnl;
    private JPanel buttonPnl;
    private JPanel mainPnl;
    //labels
    private JLabel headingLb;
    private JLabel idLb;
    private JLabel nameLb;
    private JLabel surnameLb;
    private JLabel genderLb;
    private JLabel dobLb;
    private JLabel disLb;
    private JLabel foodLb;
    
    //textfields
    private JTextField idTx;
    private JTextField nameTx;
    private JTextField surnameTx;
    private JTextField dobTx;
    //Radio button
    private JRadioButton male;
    private JRadioButton female;
    //Group button
    private ButtonGroup group;
    //private comboBox
    private JComboBox option;
    //checkBox
    private JCheckBox c;
    private JCheckBox f;
    private JCheckBox b;
     private JCheckBox p;
    //area
    private JTextArea comment;
    //pane
    private JScrollPane pane;
    //buttons
    private JButton store;
    private JButton delete;
    private JButton getAll;
    private JButton clear;
    private JButton exit;
    //JMainBar
    private JMenuBar mainBar;
    //JMenu
    private JMenu help;
    //MenuItem
    private JMenuItem about;
    //sockets
    private final InetAddress net;
    private Socket socket;
    private BufferedReader in;
    private PrintWriter send;
    public ClientFrame() throws UnknownHostException, IOException {
        //declare of socktes and readres
        net = InetAddress.getByName("127.0.0.1");
       socket = new Socket(net,8585);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        send = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())),true);
        //Inst mainBar
        mainBar =new JMenuBar();
        //Insta menu
        help = new JMenu("Help");
        //inst item
        about = new JMenuItem("About");
        about.addActionListener(new aboutMenu());
        //add ite to res menu
        help.add(about);
        //add to bar
        mainBar.add(about);
        //set frame
        setTitle("Varsity");
        setSize(500,300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        //inst panels
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        idPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        namePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        surnamePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPnl =new JPanel(new FlowLayout(FlowLayout.LEFT));
        dobPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        disPnl  = new JPanel(new FlowLayout(FlowLayout.LEFT));
        foodPnl  = new JPanel(new FlowLayout(FlowLayout.LEFT));
        areaPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        areaPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1),"Comment"));
        comboPnl = new JPanel (new GridLayout(8,1));
        comboPnl.setBorder(new TitledBorder(new LineBorder(Color.BLACK,1),"Details"));
        headComboPnl = new JPanel(new BorderLayout());
        buttonPnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        mainPnl = new JPanel(new BorderLayout());
        //insta labels
        headingLb = new JLabel("Varsity Data");
        headingLb.setBorder(new BevelBorder(BevelBorder.RAISED));
        headingLb.setFont(new Font(Font.SERIF,Font.ITALIC+ Font.BOLD,20));
        headingLb.setForeground(Color.red);
        idLb = new JLabel("ID Number: ");
        nameLb = new JLabel("Name: ");
        surnameLb = new JLabel("Surname: ");
        genderLb = new JLabel("Gender: ");
        dobLb = new JLabel("Date of Birth(yyyy-mm-dd): ");
        disLb = new JLabel("Disability: ");
        foodLb = new JLabel("Food: ");
        //inst text
        idTx = new JTextField(30);
        nameTx = new JTextField(30);
        surnameTx = new JTextField(30);
        dobTx = new JTextField(30);
        //ins group
        group = new ButtonGroup();
        //radio
        male = new JRadioButton("M");
        female = new JRadioButton("F");
        group.add(male);
        group.add(female);
        //combo
        option = new JComboBox();
        option.addItem("--Option--");
        option.addItem("No");
        option.addItem("Yes");
        //Check box
        c = new JCheckBox("Chicken");
        f = new JCheckBox("Fish");
        b = new JCheckBox("Beef");
        p = new JCheckBox("Pork");
        //area
        comment = new JTextArea(20,40);
        comment.setEditable(false);
        pane = new JScrollPane(comment,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        //Buttons
        store = new JButton("Store");
        store.addActionListener(new StoreButton());
        delete = new JButton("Delete");
        delete.addActionListener(new DeleteButton());
        getAll = new JButton("Get");
        getAll.addActionListener(new getButton());
        clear = new JButton("Clear");
        clear.addActionListener(new clearButton());
        exit = new JButton("Exit");
        exit.addActionListener(new exitButton());
        //adding res panles
        headingPnl.add(headingLb);
        idPnl.add(idLb);
        idPnl.add(idTx);
        namePnl.add(nameLb);
        namePnl.add(nameTx);
        surnamePnl.add(surnameLb);
        surnamePnl.add(surnameTx);
        genderPnl.add(genderLb);
        genderPnl.add(male);
        genderPnl.add(female);
        dobPnl.add(dobLb);
        dobPnl.add(dobTx);
        disPnl.add(disLb);
        disPnl.add(option);
        foodPnl.add(foodLb);
        foodPnl.add(c);
        foodPnl.add(f);
        foodPnl.add(b);
        foodPnl.add(p);
        comboPnl.add(idPnl);
        comboPnl.add(namePnl);
        comboPnl.add(surnamePnl);
        comboPnl.add(genderPnl);
        comboPnl.add(dobPnl);
        comboPnl.add(disPnl);
        comboPnl.add(foodPnl);
        headComboPnl.add(headingPnl,BorderLayout.NORTH);
        headComboPnl.add(comboPnl,BorderLayout.CENTER);
        areaPnl.add(pane);
        buttonPnl.add(store);
        buttonPnl.add(delete);
        buttonPnl.add(getAll);
        buttonPnl.add(clear);
        buttonPnl.add(exit);
        //main pan
        mainPnl.add(headComboPnl,BorderLayout.NORTH);
        mainPnl.add(areaPnl,BorderLayout.CENTER);
        mainPnl.add(buttonPnl,BorderLayout.SOUTH);
        //add to frame
        add(mainPnl);
        //set menu
         setJMenuBar(mainBar);
        //pack frame set visible
          pack();
         setVisible(true);
    }

    private class aboutMenu implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
           comment.setText("The application is about the baisc of client and server."+"\n"+
                            "Where a student enters his/her details and as a varsity we are storing the details"+"\n"+
                            "Inside database for later use"); 
        }

        
    }

 


    private  class StoreButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            //VARIAVE
            String respond,data;
           //Read the text fields
           String ids = idTx.getText();
           Integer id = Integer.parseInt(ids);//convert to int
           String name = nameTx.getText();
           String surname = surnameTx.getText();
           Character gender ='M';
           //getting gender
           if(female.isSelected()){
               gender = 'F';
           }else{
               gender = 'M';
           }
           //Birth
           String dates = dobTx.getText();
           //get dis
           String dis = (String) option.getSelectedItem();
           //Get food,
           String food="",ch="",fh="",be="",po="";
  
           //statement
           if(c.isSelected()){
                ch = "Chicken";
           }
           if(f.isSelected()){
                fh = "Fish";
           }
            if(b.isSelected()){
                be = "Beef";
           }
           if(f.isSelected()){
                po = "Pork";
           }
           food = ch+" "+fh+" "+" "+be+" "+po;
           //con data
           data = id + "#"+name+"#"+surname + "#"+gender+ "#"+dates+"#"+dis+"#"+food;
           send.println(1+"#"+data);
                //clrea
           idTx.setText("");
           nameTx.setText("");
           surnameTx.setText("");
           group.clearSelection();
           dobTx.setText("");
            option.setSelectedIndex(0);
           c.setSelected(false);
           f.setSelected(false);
           b.setSelected(false);
           p.setSelected(false);
           //set focus
           idTx.setFocusable(true);
            try {
                //reading
                respond = in.readLine();
                comment.setText(respond);
            } catch (IOException ex) {
                Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        
    }

    private  class DeleteButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String put,data;
            Integer id;
          put = JOptionPane.showInputDialog(null,"Enter id"); 
          id = Integer.parseInt(put);
          //data = id;
          //send to server
          send.println(2+"#"+id);
            try {
                //reading
                data = in.readLine();
                comment.setText(data);
            } catch (IOException ex) {
                Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
          
        }
         
        
    }

    private class clearButton implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
           //clrea
           idTx.setText("");
           nameTx.setText("");
           surnameTx.setText("");
           group.clearSelection();
           dobTx.setText("");
           option.setSelectedIndex(0);
           c.setSelected(false);
           f.setSelected(false);
           b.setSelected(false);
           p.setSelected(false);
           comment.setText("");
           //set focus
           idTx.setFocusable(true);
        }

    }

    private  class getButton implements ActionListener {

       
        @Override
        public void actionPerformed(ActionEvent e) {
            String data,all,record="";
            //send to server
            all= "Client request all data";
              send.println(3+"#"+all);
            try {
              
                //reading
               data = in.readLine();
               String []token=data.split("#");
              
                for (String student : token) {
                    record +=student+"\n";
                }
              
               comment.setText(record);
                 
            } catch (IOException ex) {
                Logger.getLogger(ClientFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }

    private  class exitButton implements ActionListener {

       
        @Override
        public void actionPerformed(ActionEvent e) {
         
          String data = "exit";
          send.println(data);
           System.exit(0);
        }
    }
    
}
